# Source audit

PASS

Local Git DCDLP-main and remote /home/ubuntu/lchr_v2 runtime verified. Existing frozen R, V17.4, PAPER-SPRINT implementation and protocol hashes matched. Server runtime has no .git; remote commit equality is not asserted. ZC-NBPR proposal was not found by scoped project search. R-HSPE manuscript was reviewed as evidence boundaries, not altered. R definition and all historical outputs remain unchanged; new caches/jobs isolated in DA_NBR_V30A. Historical SCREEN caches reused readonly after all stored member hashes match; sampler and candidate populations identical. Masked original train adjacency only enters path features. Each validation query is evaluated without its held-out edge. Train queries mask their own target; NCNC additionally retains its original batch-positive mask. No validation/test labels fit structural features. Numeric split/source hashes in SOURCE_IDENTITY and common READY records.
