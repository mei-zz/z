# V30A decision

{
  "PATH_INFORMATION_GAIN": "UNRESOLVED",
  "DYNAMIC_TRANSITION_GAIN": "UNRESOLVED",
  "ADAPTIVE_DEPTH_GAIN": "NO",
  "RESIDUAL_GATE_GAIN": "UNRESOLVED",
  "TRUE_PATH_CORRESPONDENCE_GAIN": "UNRESOLVED",
  "PERFORMANCE_SIGNAL": "EXPLORATORY",
  "NOVELTY_STATUS": "NOT_AUDITED",
  "replicated_datasets": [],
  "positive_mean_stageA_leads": [
    "pubmed"
  ],
  "gate_reason": "No isolated ungated capacity-matched control in requested B0\u2013B9; gated full-vs-baseline cannot identify gate causality",
  "test_opened": false,
  "innovation1_modified": false,
  "next_expected_step": "RESEARCH_REVIEW"
}

YES means reproduced conditional signal within the available fixed inner protocol, not novelty. NO means no positive conditional signal in the tested comparison, not universal impossibility. Exploratory signals and raw paired effects remain preserved. Component tests that were not replicated remain unresolved. Capacity matched is nominal; input-dependent effective ranks differ and are disclosed.
