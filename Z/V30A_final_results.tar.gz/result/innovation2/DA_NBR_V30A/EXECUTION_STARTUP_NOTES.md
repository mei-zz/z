# V30A startup record

Workspace verified: DCDLP-main. Runtime project: /home/ubuntu/lchr_v2. Source identity and frozen-definition checks passed. The optional ZC-NBPR proposal was not found in the project. The R-HSPE manuscript and protocol reconciliation were read; no historical evidence or manuscript was edited.

Exact candidate-masked length3/4 paths passed independent brute-force DFS on 20 random small graphs, all candidate pairs and both orientations. Cora, PubMed and Citeseer show nonconstant path counts. P3/P4 do not rescue T=0 in these populations. Endpoint-exclusive MULT uses the actual V27/V28 compatibility multiplicity/support definition, distinct from R-HSPE T/S.

Added parameter counts: B0=0; B1=75; B2–B9=274 (75 frozen context-template parameters plus199 new parameters). B3 uses an actively learned count-only capacity mapper; B8 uses an actively learned duplicated-GRAPH capacity branch. The exact mappings and effective-capacity limitations are preregistered in 00_PROTOCOL.md. No independent residual-gate effect can be inferred without an ungated contrast, so that component will remain UNRESOLVED.

Before training, the final reporting rule was corrected to retain any positive-mean research lead even when the stricter 2/3-wins promotion gate fails. The preliminary path-preparation supervisor was interrupted and restarted with the updated source freeze. There were zero training results at that restart; no trained metric, model architecture, optimizer setting or selected outcome was changed. Interrupted startup logs remain preserved. Cached exact paths were reused after their hashes were checked.

The final source-frozen supervisor passed Cora and PubMed B6 independent-process repeatability checks: scores bitwise equal, maximum drift0. Both complete five-epoch runs had finite losses and passed symmetry checks. Stage A is running detached, with six simultaneous jobs. A startup observation showed14/60 completed, V100100% utilization and7714MiB used, approximately5.2GiB disk free. This is a point-in-time startup observation, not final evidence.

The server supervisor automatically performs the authorized conditional independent seeds, fixed Citeseer validation transfer and one training-derived inner split when the preregistered gates allow them. Failures stop the runner and record the traceback; no rescue tuning, path truncation, approximation or new candidate is launched. Training/validation only; test remains sealed.

The user requested ending this chat after stable startup. No long-term chat monitoring or recurring automation is created. Retrieve the complete final results in a later request.
