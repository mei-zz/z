# V18.1 — CHRI stability continuation

STATE: RUNNING
FINAL_STATUS: PENDING
REASON: Reproduce historical V18 before running any optimization variant.

**Historical integrity:** V18 failed its original preregistered gate: CHRI_KILL / CHRI_TRANSFER_WEAK. V18.1 is a user-authorized weak-signal stabilization continuation with a different research goal. V18 is not retroactively changed.

## 1. Was V18 reproduced?

NOT_RUN. Exact traces/initialization are required; all five heldout trajectories must meet preregistered numerical tolerances.

## 2–3. Why RAW was unstable; predictability of R from Z

See 02_INSTABILITY_DIAGNOSIS.md/json for per-seed trajectories, relation/correction norms, correction signs, harmful/beneficial fractions, train-only nuisance MSE/R²/cosine, and residual variance. Failed versus winning seed comparisons are descriptive; three seeds do not prove that redundancy causes instability.

## 4–6. Residualization, zero initialization, and conservative gating

V1 uses q(Z,R-stopgrad(m(Z))); V2 uses qZ(Z)+zero-init g(R_delta); V3 uses qZ(Z)+sigmoid(a([Z,R_delta]))*zero-init g(R_delta). All use the original encoders and R operator; m fits detached Z/r without labels. Lambda_nuis=1; no conditional-null regularization. V18 RAW already zero-initializes its final concat decoder; V2 isolates a separately initialized additive relation head, so this is not a claim that RAW lacked all zero initialization.

| Phase | Dataset | Method vs Z | Mean Delta CE | Median Delta CE | CE wins | Mean Delta MRR | MRR wins |
|---|---|---|---:|---:|---:|---:|---:|

## 7. Selected variant

NONE. 

## 8–9. Cora and PubMed stability before/after

The table above contains paired CE/MRR and wins. Phase A requires a minimum dataset CE-win count higher than RAW, with both datasets meeting ≥2/3, positive mean CE and nonnegative mean MRR, plus architecture-matched shuffle advantage. Phase B requires ≥3/5, positive mean/median CE, nonnegative mean MRR, and true advantage over NULL and SHUFFLE.

## 10–11. Relation correspondence and parameter capacity

{
  "state": "NOT_RUN",
  "reason": "Prerequisite stage pending."
}

## 12. Remaining signal

PENDING. Reproduce historical V18 before running any optimization variant.

## Correction behavior

See 07_CORRECTION_BEHAVIOR.md and CORRECTION_BEHAVIOR.json. Explicit V2/V3 relation residuals and same-model zero-slot RAW/V1 counterfactuals are reported separately from the difference to an independently trained Z model. NULL and correspondence contrasts are required before interpreting reduced harmful corrections as relation-specific stability.

TEST_OPENED: NO
CORA_TEST: NOT_RUN
PUBMED_TEST: NOT_RUN
CITESEER: NOT_RUN
I1_I2_COMPLEMENTARITY: NOT_RUN
INNOVATION_1_MODIFIED: NO
INNOVATION_2_FINAL_FROZEN: NO
INNOVATION_3: NOT_STARTED
