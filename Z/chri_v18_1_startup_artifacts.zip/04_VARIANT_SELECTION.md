# 04_VARIANT_SELECTION.md

NOT_RUN: prerequisite stage pending.
