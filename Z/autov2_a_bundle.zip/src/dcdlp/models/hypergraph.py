from __future__ import annotations

"""Small, leakage-safe hypergraph branches for link-prediction ablations.

The branch deliberately uses a fixed incidence construction rather than
attention or a learned edge selector.  A star hyperedge is the closed
neighborhood of one node in the *already target-masked* message graph.  The
``complement`` mode removes the component of the hypergraph message that is
parallel to the pairwise node representation before applying the same linear
map as the raw control.  This makes the mechanism testable as an
"independent higher-order residual" hypothesis.
"""

import torch
from torch import nn


HYPERGRAPH_MODES = {
    "disabled",
    "raw",
    "complement",
    "pairwise",
    "shuffled",
    "random_topk",
    "global_router",
    "lchr",
    "size_calibration",
    "shuffled_cohesion",
    "sshc",
}


def _star_members(edge_index: torch.Tensor, num_nodes: int) -> list[torch.Tensor]:
    """Build closed-neighborhood hyperedges from the supplied message graph."""
    neighbors = [set() for _ in range(num_nodes)]
    for raw_u, raw_v in edge_index.detach().cpu().t().tolist():
        u, v = int(raw_u), int(raw_v)
        if u == v:
            continue
        neighbors[u].add(v)
        neighbors[v].add(u)
    members: list[torch.Tensor] = []
    for center, values in enumerate(neighbors):
        if not values:
            continue
        members.append(
            torch.as_tensor(
                [center, *sorted(values)],
                dtype=torch.long,
                device=edge_index.device,
            )
        )
    return members


def _aggregate_incidence(
    h: torch.Tensor,
    hyperedges: list[torch.Tensor],
    *,
    pairwise_projection: bool,
    edge_weights: torch.Tensor | None = None,
) -> torch.Tensor:
    """Apply an unweighted incidence aggregation without materializing H."""
    output = h.new_zeros(h.shape)
    counts = h.new_zeros((h.shape[0], 1))
    for edge_id, members in enumerate(hyperedges):
        values = h[members]
        if pairwise_projection:
            if len(members) <= 1:
                continue
            # Projection control: retain the same hyperedge membership but
            # replace the set-valued message by its ordinary pairwise
            # co-membership average.
            contribution = (values.sum(dim=0, keepdim=True) - values) / (len(members) - 1)
        else:
            summary = values.mean(dim=0, keepdim=True)
            contribution = summary.expand(len(members), -1)
        if edge_weights is not None:
            contribution = contribution * edge_weights[edge_id]
        output.index_add_(0, members, contribution)
        counts.index_add_(
            0,
            members,
            h.new_ones((len(members), 1)),
        )
    return output / counts.clamp_min(1.0)


class IncidenceResidualComplement(nn.Module):
    """Standard hypergraph control plus a pairwise-complement residual mode.

    ``raw`` is the hypergraph-only control.  ``pairwise`` is a matched
    ordinary co-membership projection.  ``shuffled`` preserves the raw
    message distribution but breaks its node assignment.  ``complement``
    subtracts the per-node projection onto the pairwise encoder state before
    applying the same trainable map as ``raw``.
    """

    def __init__(self, hidden_dim: int, mode: str = "complement") -> None:
        super().__init__()
        if mode not in HYPERGRAPH_MODES - {"disabled"}:
            raise ValueError(
                f"Unknown hypergraph_mode {mode!r}; expected one of "
                f"{sorted(HYPERGRAPH_MODES)}"
            )
        self.mode = mode
        self.message_linear = nn.Linear(hidden_dim, hidden_dim, bias=False)
        # A near-zero sigmoid coefficient makes the calibrated modes start
        # almost exactly at the raw global hypergraph branch.
        self.calibration_logit = nn.Parameter(torch.tensor(-5.0))

    @staticmethod
    def _standardized_structure(
        edge_index: torch.Tensor, hyperedges: list[torch.Tensor], signal: str
    ) -> torch.Tensor:
        num_nodes = int(edge_index.max().item()) + 1 if edge_index.numel() else 0
        neighbors = [set() for _ in range(num_nodes)]
        for u, v in edge_index.detach().cpu().t().tolist():
            neighbors[u].add(v)
            neighbors[v].add(u)
        values = []
        for members in hyperedges:
            ids = members.detach().cpu().tolist()
            if signal == "size":
                values.append(float(torch.log1p(torch.tensor(float(len(ids))))))
                continue
            center, leaves = ids[0], ids[1:]
            possible = len(leaves) * (len(leaves) - 1) // 2
            closed_pairs = sum(
                1 for i, u in enumerate(leaves)
                for v in leaves[i + 1:] if v in neighbors[u]
            )
            values.append(closed_pairs / possible if possible else 0.0)
        feature = torch.as_tensor(values, dtype=torch.float32, device=edge_index.device)
        if signal == "shuffled" and len(feature) > 1:
            generator = torch.Generator(device="cpu").manual_seed(0)
            order = torch.randperm(len(feature), generator=generator).to(feature.device)
            feature = feature[order]
        return (feature - feature.mean()) / feature.std(unbiased=False).clamp_min(1e-8)

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        hyperedges = _star_members(edge_index, h.shape[0])
        weights = None
        if self.mode in {"size_calibration", "shuffled_cohesion", "sshc"}:
            signal = "size" if self.mode == "size_calibration" else (
                "shuffled" if self.mode == "shuffled_cohesion" else "cohesion"
            )
            feature = self._standardized_structure(edge_index, hyperedges, signal)
            alpha = torch.sigmoid(self.calibration_logit)
            weights = 1.0 + alpha * torch.tanh(feature)
        raw = _aggregate_incidence(
            h,
            hyperedges,
            pairwise_projection=self.mode == "pairwise",
            edge_weights=weights,
        )
        if self.mode == "complement":
            coefficient = (raw * h).sum(dim=-1, keepdim=True)
            denominator = h.square().sum(dim=-1, keepdim=True).clamp_min(1e-8)
            raw = raw - coefficient / denominator * h
        elif self.mode == "shuffled" and len(raw) > 1:
            raw = torch.roll(raw, shifts=1, dims=0)
        return self.message_linear(raw)


class LinkHyperedgeRouter(nn.Module):
    """Candidate-local star-hyperedge context from the masked message graph."""

    def __init__(self, hidden_dim: int, branch_dim: int, mode: str, topk: int = 8):
        super().__init__()
        if mode not in {"random_topk", "global_router", "lchr"}:
            raise ValueError(mode)
        self.mode, self.topk = mode, topk
        self.router = nn.Sequential(
            nn.Linear(hidden_dim * 5 + 5, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self.projection = nn.Linear(hidden_dim, branch_dim, bias=False)
        self.beta = nn.Parameter(torch.tensor(0.1))
        self.last_diagnostics: dict[str, object] = {}

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor,
                pairs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        members = _star_members(edge_index, h.shape[0])
        zero = h.new_zeros((len(pairs), self.projection.out_features))
        if not members:
            self.last_diagnostics = {"pool_sizes": [0] * len(pairs), "entropy": [0.0] * len(pairs)}
            return zero, h.new_zeros(len(pairs))
        edge_repr = torch.stack([h[item].mean(0) for item in members])
        member_sets = [set(item.tolist()) for item in members]
        incident = [[] for _ in range(h.shape[0])]
        neighbors = [set() for _ in range(h.shape[0])]
        for eid, item in enumerate(member_sets):
            for node in item:
                incident[node].append(eid)
        for u, v in edge_index.detach().cpu().t().tolist():
            neighbors[u].add(v)
            neighbors[v].add(u)
        chosen, structural, pool_sizes = [], [], []
        for u, v in pairs.detach().cpu().tolist():
            pool = sorted(set(incident[u]) | set(incident[v]))
            pool_sizes.append(len(pool))
            if len(pool) > 32:
                pool = sorted(pool, key=lambda e: (-(len(member_sets[e] & neighbors[u]) +
                                                     len(member_sets[e] & neighbors[v])), e))[:32]
            if self.mode == "random_topk":
                pool = sorted(pool, key=lambda e: ((u * 73856093 ^ v * 19349663 ^ e * 83492791) & 0xffffffff))[:self.topk]
            features = []
            for eid in pool:
                group = member_sets[eid]
                features.append([float(u in group), float(v in group),
                                 len(group & neighbors[u]) / max(1, len(neighbors[u])),
                                 len(group & neighbors[v]) / max(1, len(neighbors[v])),
                                 len(group) / max(1, h.shape[0])])
            chosen.append(pool)
            structural.append(features)
        width = min(self.topk, max(map(len, chosen), default=0))
        if width == 0:
            self.last_diagnostics = {"pool_sizes": pool_sizes, "entropy": [0.0] * len(pairs)}
            return zero, h.new_zeros(len(pairs))
        ids = torch.zeros((len(pairs), width), dtype=torch.long, device=h.device)
        phi = h.new_zeros((len(pairs), width, 5))
        mask = torch.zeros((len(pairs), width), dtype=torch.bool, device=h.device)
        # Score all prefiltered candidates before choosing the learned Top-K.
        scores = []
        for i, pool in enumerate(chosen):
            if not pool:
                scores.append(h.new_empty(0))
                continue
            e = edge_repr[pool]
            u, v = pairs[i]
            q = torch.cat([h[u], h[v], h[u] * h[v], (h[u] - h[v]).abs()])
            f = h.new_tensor(structural[i])
            if self.mode == "global_router":
                q = torch.zeros_like(q)
                f = torch.zeros_like(f)
            logits = self.router(torch.cat([e, q.expand(len(pool), -1), f], -1)).squeeze(-1)
            scores.append(logits)
            selected = torch.topk(logits, min(width, len(pool))).indices if self.mode != "random_topk" else torch.arange(min(width, len(pool)), device=h.device)
            count = len(selected)
            ids[i, :count] = torch.as_tensor(pool, device=h.device)[selected]
            phi[i, :count] = f[selected]
            mask[i, :count] = True
        z = edge_repr[ids]
        rows = []
        for i, pool in enumerate(chosen):
            if not pool:
                rows.append(h.new_zeros(width))
                continue
            selected = torch.topk(scores[i], min(width, len(pool))).indices if self.mode != "random_topk" else torch.arange(min(width, len(pool)), device=h.device)
            row = h.new_full((width,), -1e9)
            row[:len(selected)] = scores[i][selected] if self.mode != "random_topk" else 0.0
            rows.append(row)
        logits = torch.stack(rows)
        alpha = torch.softmax(logits.masked_fill(~mask, -1e9), -1)
        alpha = torch.where(mask, alpha, 0.0)
        context = (alpha.unsqueeze(-1) * z).sum(1)
        entropy = -(alpha * alpha.clamp_min(1e-12).log()).sum(-1)
        self.last_diagnostics = {"pool_sizes": pool_sizes, "entropy": entropy.detach().cpu().tolist(),
                                 "top1": alpha.max(-1).values.detach().cpu().tolist(),
                                 "weights": [
                                     [[sorted(member_sets[int(ids[i, j])]),
                                       float(alpha[i, j].detach().cpu())]
                                      for j in range(width) if bool(mask[i, j])]
                                     for i in range(len(pairs))
                                 ]}
        return self.beta * self.projection(context), entropy
