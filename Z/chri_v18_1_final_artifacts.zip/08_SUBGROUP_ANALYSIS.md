# 08_SUBGROUP_ANALYSIS.md

NOT_RUN: Reproduced trajectory differs materially from historical V18. No new variant was run.
