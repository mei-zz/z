# Novelty ledger

No candidate has reached Stage 2. A focused local-internet search is mandatory before any Stage 2 launch. Risks are recorded in IDEA_LEDGER.md; no novelty or priority claim is made.

| Candidate | Search / closest work | Overlap | Differentiator to verify | Year / venue | NOVELTY_STATUS | Evidence |
|---|---|---|---|---|---|---|
| V12-F1 | Pending performance gate | Pairwise / hard-negative ranking objectives | Frozen SH75 pool, batch-top subset, random-ten control | — | NOT_SEARCHED | Stage 2 not reached |
| V12-G1 | Pending performance gate | Positive weighting / structural confidence | Train-only leave-one-edge-out closure rank and shuffled-weight control | — | NOT_SEARCHED | Stage 2 not reached |
| V12-C1 | Pending performance gate | Bilinear / elementwise-product decoders | DCDLP residual plus exact parameter-matched self-moment control | — | NOT_SEARCHED | Stage 2 not reached |
| V12-D1 | Pending performance gate | Ego-context / multi-scale link representations | Target-masked pair-context residual and node-permuted-context control | — | NOT_SEARCHED | Stage 2 not reached |

Focused novelty searches must cite primary papers or official proceedings and record exact title, authors, year, venue, and overlap before promotion.
