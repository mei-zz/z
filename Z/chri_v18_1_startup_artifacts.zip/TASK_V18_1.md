# V18.1 — CHRI RESIDUALIZATION & STABILITY OPTIMIZATION
# Innovation 2 continuation
#
# PURPOSE:
# Keep CHRI alive as a weak-signal research direction and investigate
# whether instability comes from redundancy / harmful integration with Z.
#
# IMPORTANT:
# V18 historical result must remain unchanged:
# CHRI_KILL / CHRI_TRANSFER_WEAK under the original preregistered V18 gate.
#
# V18.1 is a NEW exploratory continuation authorized by the user.
# Do not rewrite, overwrite, or reinterpret V18 artifacts.

STATUS: READY_TO_EXECUTE

GOAL:

解决 V18 暴露出的具体问题：

    relation signal appears to exist,
    but direct integration with Z is seed-unstable.

V18 observed:

Cora:
    true vs Z:
        Delta CE > 0
        Delta MRR > 0
        3/3 CE wins

PubMed:
    true vs Z:
        mean Delta CE > 0
        mean Delta MRR > 0
        only 1/3 CE wins

But:

Cora:
    true relation > shuffled relation
    3/3 CE wins

PubMed:
    true relation > shuffled relation
    3/3 CE wins

Working hypothesis:

    R contains useful relation-specific signal,
    but a large part of R is redundant with Z
    and/or the relation correction is too unconstrained,
    causing harmful seed-dependent updates.

V18.1 tests whether:

    residualizing R against Z
    and conservatively gating its correction

can improve stability.

Do NOT start a new innovation direction.
Do NOT modify Innovation 1.
Do NOT open test sets unless explicitly allowed later in this protocol.

==================================================
0. WORKSPACE AND ARTIFACT CHECK
==================================================

Confirm workspace:

    DCDLP-main

If workspace is not DCDLP-main:

    STOP.

Read:

    result/innovation2/CHRI_V18/
or actual existing V18 directory.

Also read:

    HYPERGRAPH_RESEARCH/R_HSPE_FINAL_FROZEN/
    HYPERGRAPH_RESEARCH/PAPER_PREP/INNOVATION_1_R_HSPE/

Confirm:

    V18 status = CHRI_KILL / CHRI_TRANSFER_WEAK
    Innovation 1 = FINAL_FROZEN

Do not modify either artifact set.

Create new directory:

    result/innovation2/CHRI_V18_1/

or follow existing repository convention if V18 uses another root.

==================================================
1. NON-NEGOTIABLE FROZEN COMPONENTS
==================================================

Freeze from V18:

    dataset splits
    validation candidates
    negative samples / negative protocol
    frozen NCNC checkpoint
    B definition
    P_u / P_v definition
    C handling
    Z definition
    hyperedge construction
    target masking
    R_CAT input semantics
    evaluator
    seeds
    optimizer family
    batch construction

No new feature engineering.

No new hyperedge statistics.

No new motif features.

No new candidate structural features.

No R-HSPE tuning.

The purpose of V18.1 is:

    integration stabilization

not:

    architecture search.

==================================================
2. REPRODUCE V18 FIRST
==================================================

Before any new variant:

reproduce the V18 Phase A arms for seeds:

    0, 1, 2

datasets:

    Cora
    PubMed

epochs:

    5

at least:

R0:
    Z

R1:
    Z + raw R_CAT

R2:
    Z + shuffled R_CAT

Confirm that reproduced paired results agree with V18 within normal
deterministic / numerical tolerance.

Write:

    01_V18_REPRODUCTION.json

If reproduction materially disagrees:

    STATUS = REPRODUCTION_MISMATCH
    STOP

Do not optimize on top of a mismatched baseline.

==================================================
3. DIAGNOSE WHY RAW R IS UNSTABLE
==================================================

For every seed in V18 reproduction, log:

    CE trajectory per epoch
    MRR trajectory per epoch

For raw relation branch log:

    ||r||
    ||relation correction||
    mean correction
    std correction
    correction sign distribution
    correlation(correction, baseline logit)
    correlation(correction, label)
    fraction of candidates whose prediction is changed
    fraction changed in correct direction
    fraction changed in wrong direction

Also estimate:

    how predictable r is from Z

using a small nuisance predictor:

    m_psi(Z) -> r

Report:

    nuisance MSE
    R^2 if meaningful
    cosine similarity between r and m(Z)
    variance of residual r - m(Z)

The purpose:

determine whether failed seeds have:

    stronger Z-R redundancy
    larger correction magnitude
    worse correction sign
    unstable relation norm

Write:

    02_INSTABILITY_DIAGNOSIS.md
    02_INSTABILITY_DIAGNOSIS.json

Do not alter the model based on individual seed results beyond the
predefined variants below.

==================================================
4. DEFINE THE FIXED V18.1 VARIANTS
==================================================

Do NOT broad-search architectures.

Only evaluate the following predefined variants.

--------------------------------
V0 — RAW
--------------------------------

Same as V18:

    q(y | Z, R_CAT)

This is the reference.

--------------------------------
V1 — RESIDUALIZED RELATION
--------------------------------

Let:

    r = R_CAT(Eu, Ev)

Train nuisance predictor:

    m_psi(Z) ≈ stopgrad(r)

using:

    L_nuis = MSE(m_psi(Z), stopgrad(r))

Define:

    r_delta =
        r - stopgrad(m_psi(Z))

Predict using:

    q(y | Z, r_delta)

Important:

m_psi cannot use labels.

Its only task is to predict the relation representation from Z.

Interpretation:

    remove relation content predictable from existing information Z.

--------------------------------
V2 — RESIDUALIZED + ZERO-INIT RESIDUAL
--------------------------------

Use same:

    r_delta

But do not concatenate it into a free classifier.

Instead:

    base_logit = q_Z(Z)

    correction =
        g(r_delta)

Initialize final correction head so that:

    correction = 0

at initialization.

Final:

    logit =
        base_logit
        +
        correction

The baseline predictor must initially be unchanged.

--------------------------------
V3 — RESIDUALIZED + ZERO-INIT GATED RESIDUAL
--------------------------------

Use:

    r_delta

Compute:

    correction =
        g(r_delta)

Compute conservative gate:

    alpha =
        sigmoid(a([Z, r_delta]))

Final:

    logit =
        base_logit
        +
        alpha * correction

Initialize so that effective correction is approximately zero.

Do NOT initialize gate to produce a large correction.

Preferred initialization:

    correction head zero-init

so initial final score equals base score exactly.

This is the main stabilization candidate.

==================================================
5. PARAMETER CONTROLS
==================================================

For V1/V2/V3 record:

    added parameters
    nuisance parameters
    correction parameters
    gate parameters

Create parameter-matched controls where necessary.

At minimum:

NULL-V3:

same added trainable parameter count as V3,
but relation input is zero/null.

The purpose is to rule out:

    extra capacity only.

Do not inflate parameter count unnecessarily.

==================================================
6. TRAINING OBJECTIVE
==================================================

Primary prediction loss:

    binary cross entropy

For V1/V2/V3:

    L =
        L_pred
        +
        lambda_nuis * L_nuis

Use:

    lambda_nuis = 1.0

unless loss-scale mismatch is numerically extreme.

If normalization is required:

normalize losses by running scale only.

Do not sweep lambda based on final metric.

For V3:

do NOT yet add conditional-null regularization.

This phase isolates:

    residualization
    +
    conservative gating

Conditional-null CRIB training belongs to a later phase only if
stability is recovered.

==================================================
7. PHASE A — STABILITY SCREEN
==================================================

Datasets:

    Cora
    PubMed

Seeds:

    0,1,2

Epochs:

    5

Validation only.

Arms:

A0:
    Z

A1:
    Z + RAW R_CAT

A2:
    Z + V1 residualized R

A3:
    Z + V2 zero-init residualized R

A4:
    Z + V3 gated zero-init residualized R

A5:
    V3 parameter-matched NULL

A6:
    V3 with shuffled true relation input

All arms must use paired:

    seeds
    negatives
    candidates
    frozen backbone
    training order where applicable

==================================================
8. PRIMARY V18.1 QUESTION
==================================================

The main objective is NOT:

    highest single-seed MRR.

The objective is:

    improved cross-seed stability.

For each variant report:

    Delta CE vs Z
    Delta MRR vs Z
    CE seed wins
    MRR seed wins

Also:

    true vs shuffle
    true vs null

Primary stability score:

For each dataset:

    number of seeds with:
        CE(variant) < CE(Z)

Secondary:

    number of seeds with:
        MRR(variant) > MRR(Z)

==================================================
9. PHASE A DECISION
==================================================

A stabilization candidate is promising if:

Cora:

    >= 2/3 CE wins vs Z
    mean Delta CE > 0

PubMed:

    >= 2/3 CE wins vs Z
    mean Delta CE > 0

and both datasets:

    mean Delta MRR >= 0

and:

    true relation variant
    >
    shuffled relation variant

in mean Delta CE.

Prefer a variant that improves seed stability over RAW.

Example:

RAW PubMed:
    1/3 CE wins

V3 PubMed:
    2/3 or 3/3 CE wins

is meaningful stabilization.

Do not require huge gain.

If no new variant improves stability beyond RAW:

    V18_1_STABILIZATION_FAILED

But DO NOT rewrite CHRI as globally impossible.

Record:

    CHRI_WEAK_SIGNAL_ONLY

and stop.

==================================================
10. SELECT ONE VARIANT ONLY
==================================================

If more than one variant passes:

select using this order:

1.
higher minimum CE improvement across seeds

2.
more CE seed wins

3.
higher mean Delta CE

4.
higher mean Delta MRR

5.
fewer added parameters

Do not select by best single seed.

Call selected variant:

    CHRI-STABLE

This is a working research name only.

Do not claim novelty yet.

==================================================
11. PHASE B — 5-SEED VALIDATION
==================================================

Only if Phase A finds a promising stabilization candidate.

Freeze selected architecture completely.

Datasets:

    Cora
    PubMed

Seeds:

    0,1,2,3,4

Epochs:

    10

Validation only.

Arms:

B0:
    Z

B1:
    RAW R_CAT

B2:
    CHRI-STABLE

B3:
    CHRI-STABLE NULL

B4:
    CHRI-STABLE SHUFFLE

No tuning.

Report:

    CE
    MRR
    Hits@10
    Hits@20
    AUC

with:

    mean
    std
    median
    per-seed values
    paired deltas
    seed wins

==================================================
12. PHASE B INTERPRETATION
==================================================

Strong stabilization evidence:

Cora and PubMed:

    mean Delta CE(CHRI-STABLE - Z) > 0

and:

    median Delta CE > 0

and:

    >= 3/5 CE wins

Prefer:

    >= 4/5

Also require:

    CHRI-STABLE > SHUFFLE
    mean Delta CE > 0

and:

    CHRI-STABLE > NULL
    mean Delta CE > 0

MRR:

    mean paired Delta MRR >= 0

If PubMed improves from V18:

    1/3 wins

to V18.1:

    >= 3/5 wins

explicitly report this as:

    STABILITY_IMPROVED

If improvement remains only isolated seeds:

    WEAK_SIGNAL_PERSISTS

==================================================
13. DO NOT OPEN TEST YET
==================================================

Even if Phase B succeeds:

DO NOT run Cora test.
DO NOT run PubMed test.
DO NOT run Citeseer.

V18.1 is specifically:

    residualization & stability optimization

not final Innovation 2 freeze.

The purpose is to determine whether CHRI can become stable enough
to justify the next formal validation.

==================================================
14. RELATION TRUE-VS-SHUFFLE CHECK
==================================================

For selected CHRI-STABLE variant:

verify per dataset:

    true relation
    vs
    matched shuffled relation

Use the same V18 conditional/matched shuffle procedure.

Do not weaken matching.

Report:

    Delta CE true - shuffle
    Delta MRR true - shuffle
    seed wins

If residualization improves Z comparison but:

    true ≈ shuffle

then the gain is not relation-specific.

Status:

    STABILIZATION_NOT_RELATION_SPECIFIC

==================================================
15. CORRECTION BEHAVIOR ANALYSIS
==================================================

For RAW and CHRI-STABLE compare:

    correction norm
    correction variance
    fraction harmful corrections
    fraction beneficial corrections
    gate mean/std if applicable
    gate by positive/negative candidates
    gate correlation with |baseline margin|
    residual relation variance

Key question:

Does stabilization work because it:

    suppresses redundant / harmful corrections

rather than merely increasing capacity?

Write:

    07_CORRECTION_BEHAVIOR.md

==================================================
16. OPTIONAL CANDIDATE SUBGROUP ANALYSIS
==================================================

Do not use this analysis for model selection.

After all Phase B results are frozen,
analyze where CHRI-STABLE helps.

Possible stratification:

    low/high endpoint degree
    low/high |Eu|
    low/high |Ev|
    relation density
    baseline confidence
    shared-support count

Report descriptive findings only.

Do not tune model based on subgroup.

Purpose:

understand why some seeds / candidates benefit.

==================================================
17. NO BROAD SEARCH
==================================================

Forbidden:

    changing hyperedge encoder depth
    changing R_CAT operator
    trying many attention architectures
    sweeping hidden dimensions
    sweeping 10 learning rates
    sweeping many lambda values
    using test feedback
    modifying NCNC
    modifying R-HSPE

This phase has exactly one goal:

    stabilize already-observed weak CHRI signal.

==================================================
18. REQUIRED ARTIFACTS
==================================================

Create:

result/innovation2/CHRI_V18_1/

At minimum:

00_PROTOCOL.md
01_V18_REPRODUCTION.json
02_INSTABILITY_DIAGNOSIS.md
02_INSTABILITY_DIAGNOSIS.json
03_PHASE_A_RESULTS.json
04_VARIANT_SELECTION.md
05_PHASE_B_RESULTS.json
06_TRUE_VS_SHUFFLE.json
07_CORRECTION_BEHAVIOR.md
08_SUBGROUP_ANALYSIS.md
FINAL_REPORT.md
SOURCE_HASHES.json
RUN_MANIFEST.json

If Phase B is not run:

write NOT_RUN with reason.

==================================================
19. FINAL REPORT MUST ANSWER
==================================================

1.
Was V18 reproduced?

2.
Why was RAW R unstable?

3.
How predictable was R from Z?

4.
Did residualization improve stability?

5.
Did zero initialization help?

6.
Did gating help?

7.
Which variant was selected?

8.
Cora:
    CE wins before vs after
    Delta CE
    Delta MRR

9.
PubMed:
    CE wins before vs after
    Delta CE
    Delta MRR

10.
Did true relation remain better than shuffled relation?

11.
Did parameter-matched NULL explain the gain?

12.
Is the remaining signal:
    stable
    weak
    or absent?

==================================================
20. ALLOWED FINAL STATES
==================================================

Use one of:

A.

V18_1_REPRODUCTION_MISMATCH

B.

CHRI_WEAK_SIGNAL_ONLY

Meaning:

    some seed/data signal remains,
    but stabilization did not improve reliability.

C.

CHRI_STABILITY_IMPROVED

Meaning:

    residualization/gating materially improved cross-seed reliability,
    but no test has been opened.

D.

CHRI_STABILITY_CONFIRMED

Meaning:

    Phase B shows stable positive validation behavior
    on both Cora and PubMed,
    with true > shuffle and true > null.

This does NOT yet mean:

    Innovation 2 FINAL_FROZEN.

==================================================
21. HISTORICAL INTEGRITY
==================================================

Do not edit V18 status.

The report must explicitly say:

    V18 failed its original preregistered gate.

V18.1 is a user-authorized continuation under a different research goal:

    weak-signal stabilization.

Do not retroactively claim:

    V18 passed.

==================================================
22. INNOVATION 1
==================================================

R-HSPE remains:

    FINAL_FROZEN

Do not change:

    method
    parameters
    protocol
    claims

Do not yet run I1 + I2 complementarity.

That belongs after CHRI stability is confirmed.

==================================================
23. FINAL C2C HANDOFF
==================================================

Return:

STATUS: EXECUTED

TASK:
CHRI_V18_1_STABILITY

WORKSPACE:
DCDLP-main

V18_REPRODUCED:
YES / NO

RAW_CORA:
DeltaCE / DeltaMRR / wins

RAW_PUBMED:
DeltaCE / DeltaMRR / wins

SELECTED_VARIANT:
RAW / V1 / V2 / V3 / NONE

SELECTED_VARIANT_DEFINITION:
...

CORA_STABILITY:
...

PUBMED_STABILITY:
...

TRUE_VS_SHUFFLE:
...

TRUE_VS_NULL:
...

PHASE_B:
PASS / FAIL / NOT_RUN

FINAL_STATUS:
V18_1_REPRODUCTION_MISMATCH
/
CHRI_WEAK_SIGNAL_ONLY
/
CHRI_STABILITY_IMPROVED
/
CHRI_STABILITY_CONFIRMED

TEST_OPENED:
NO

INNOVATION_1_MODIFIED:
NO

NEXT_EXPECTED_STEP:

If CHRI_STABILITY_CONFIRMED:
    design V18.2 formal conditional-null / CRIB validation
    and I1-I2 complementarity audit.

If CHRI_STABILITY_IMPROVED:
    review stability evidence before formal module validation.

If CHRI_WEAK_SIGNAL_ONLY:
    inspect candidate/seed failure mechanism;
    do not broad-search architectures.

Stop after handoff.
Do not start Innovation 3.