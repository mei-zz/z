# 02_INSTABILITY_DIAGNOSIS.md

NOT_RUN: Reproduced trajectory differs materially from historical V18. No new variant was run.
