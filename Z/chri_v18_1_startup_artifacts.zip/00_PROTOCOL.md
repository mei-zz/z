# V18.1 — CHRI residualization and stability optimization

Logical workspace: DCDLP-main; existing audited server checkout: /home/ubuntu/lchr_v2.
Mode: user-authorized exploratory continuation, validation only, fixed variants, staged execution.

## Historical boundary

V18 **failed its original preregistered gate**: CHRI_KILL / CHRI_TRANSFER_WEAK. Its Cora raw relation CE wins were 3/3; PubMed 1/3, despite positive mean CE/MRR effects and true-vs-shuffle CE wins of 3/3 in both datasets. V18.1 has a different research goal: weak-signal stabilization. No historical V18 code, scientific artifact, status, or checkpoint is edited. Innovation 1 remains FINAL_FROZEN (75 parameters, CONTEXT_DRIVEN, size causal claim NOT_SUPPORTED).

All new runtime code/results are under HYPERGRAPH_RESEARCH/CHRI_V18_1. Completed reports are copied to result/innovation2/CHRI_V18_1. Historical cache files are copied as independent regular files, without symlinks or hardlinks, so extending ten-epoch schedules cannot alter V18 caches. Historical artifact hashes are checked at stage boundaries and completion. Python bytecode writes into inherited V18 source directories are disabled.

## Frozen representations and sampling

Reuse the exact V18 dataset split, 20-negative validation candidates, seed-paired frozen NCNC C0 final-10 checkpoint, float32 logit+256d root predecoder B, C absorbed by NCNC, independent P_u/P_v, 321d Z, training-only raw-star construction, exact target masking, 33→32→16 shared encoder, 48→32→16 generic R_CAT operator, mean/max pooling, official evaluator, Adam family, dataset predictor LR, optimizer minibatches, floor tail policy, permutations and negative sampling protocol.

Shared endpoint/hyperedge and relation encoders retain their original architecture and input semantics. Their weights initialize on the same V18 seed streams and remain trainable, as in V18; no feature or motif statistics are added. NCNC weights remain frozen. Matching reuses the original train-only initial-Z block-PCA/kNN32 rule and donor choices, with canonical-key self exclusion, no labels and no heldout donors.

## Reproduction before variants

Datasets Cora/PubMed, seeds 0/1/2, five epochs. R0=historical A1 Z; R1=historical A2 raw relation; R2=historical A3 matched-shuffled raw relation. Run the unchanged V18 trainer in a redirected output namespace, with independent copied caches. No historical result is reused as a substitute for training reproduction.

Training traces and initialization must match exactly. Every epoch must satisfy absolute CE difference ≤1e-5, MRR difference ≤1e-4, and maximum per-candidate logit difference ≤5e-5. These tolerances are fixed before execution and allow float32 CUDA scatter roundoff. Material mismatch produces V18_1_REPRODUCTION_MISMATCH and stops before any stabilization variant.

## Instability diagnosis

Each reproduced seed stores the full five-epoch CE/MRR trajectory. At the final checkpoint record relation norm/variation, correction norm/RMS/mean/std/sign fractions, correlation with baseline logit/label, score and hard-prediction changed fractions, beneficial/harmful correction directions, and change relative to the separately fitted Z predictor.

RAW concatenation has no isolated additive relation branch. Its diagnostic relation correction is the **same fitted model's** q_RAW(Z,R)-q_RAW(Z,0), holding that model's Z and weights fixed. This is a counterfactual sensitivity diagnostic, not a causal decomposition. Total difference from a separately trained Z model is also reported.

Fit a separate 321→32→32 nuisance network for five epochs using the frozen RAW model's epoch-1 training-candidate Z/r, detached, with no labels and the same Adam LR. Report training and heldout nuisance MSE, global variance-weighted R² where variance exceeds 1e-12, cosine, residual variance and the MSE fit trajectory. No nuisance result changes variant definitions or initialization. Winning/failed-seed comparisons are descriptive associations with only three seeds per dataset.

## Fixed stabilization variants

All reuse the original V18 encoder and relation initialization. Original qZ/RAW decoder is 353→64→32→1 with a zero-initialized last layer; qZ's 32 relation input slots are zero. V18 RAW already zero-initialized its final concat classifier. V2 isolates a distinct zero-initialized additive correction head; it does not uniquely test zero initialization in isolation from its additive integration change.

- V0 RAW: exact reproduced q(Z,R), reference only.
- V1: q(Z, R-stopgrad(m(Z))). Same concat decoder as RAW.
- V2: qZ(Z)+g(R_delta), g=32→32→1 with zero last weight/bias. qZ retains the exact original qZ decoder and initialization.
- V3: qZ(Z)+sigmoid(a([Z,R_delta]))*g(R_delta), a=one Linear(353,1), weight zero and bias -2; initial alpha≈0.119203. The correction head is zero, so initial score equals qZ exactly.

m is the inherited 321→32→32 network. It receives **Z.detach()**, targets **R.detach()**, and only MSE trains m. Prediction uses R-stopgrad(m(Z)), so prediction loss cannot update m. Nuisance loss cannot update Z/P/R encoders, the classifier, correction or gate. Predictor loss can update the shared encoders as in V18. Lambda_nuis=1. No loss-scale adjustment or lambda/LR sweep. No conditional-null regularization.

Training prediction loss keeps V18's balanced positive+negative BCE sum (equivalently 2× BCE over the balanced concatenated batch); nuisance MSE is added with coefficient one. All microbatches accumulate the same canonical optimizer minibatch before one update. No dropout, batch-size change, or extra stochastic augmentation is introduced. Checkpoints are fixed-final epochs.

NULL-V3 has the same trainable parameter inventory. The relation MLP sees zero compatibility inputs and produces a learned constant pooled relation; nuisance/gate may still use Z, providing the added-capacity control. SHUFFLE-V3 takes the unchanged V18 matched donor relation. Parameters are itemized for encoder, relation, main decoder, nuisance, correction and gate; inactive inherited heads are excluded from trainable counts.

## Phase A and necessary controls

Seven primary arms: A0 Z, A1 RAW, A2 V1, A3 V2, A4 V3, A5 V3-NULL, A6 V3-SHUFFLE. Cora/PubMed × seeds0/1/2 × five epochs. A0/A1 reuse the **newly trained reproduction** checkpoints, with no extra training budget. All other arms use identical cached negative/ordering traces and initial common decoder weights.

Preliminary promising gates: both datasets ≥2/3 CE wins vs Z, positive mean Delta_CE, nonnegative mean Delta_MRR, and minimum dataset CE-win count greater than RAW's reproduced minimum. A true variant must beat its architecture-matched shuffle in mean CE on both datasets. V3-SHUFFLE is already in the primary arm list. For V1/V2, train a same-architecture SHUFFLE control **only if** that variant passes both datasets' preliminary stability gates. These are necessary correspondence controls for the three fixed variants, not additional architecture candidates. No new relation operator is created. V3-NULL is recorded at Phase A; the selected method's matched NULL is mandatory in Phase B.

If no variant passes, stop with CHRI_WEAK_SIGNAL_ONLY and V18_1_STABILIZATION_FAILED; do not infer global CHRI impossibility.

## Frozen selection and Phase B

Select one eligible variant by: (1) largest minimum paired Delta_CE across all six dataset/seed results; (2) most CE wins; (3) largest mean paired CE averaged equally across datasets; (4) largest mean paired MRR; (5) fewer added trainable parameters. Exact ties use registry order V1,V2,V3. Never use best-single-seed performance. Persist the selected architecture before Phase B.

Phase B: Cora/PubMed × seeds0…4 × ten epochs, five arms Z/RAW/selected/selected-NULL/selected-SHUFFLE. Architecture, m/g/gate sizes, alpha initialization, optimizer, losses, masking, matching and sampler are unchanged. Extend only the new cache's negative/permutation schedule with the unchanged V18 protocol; the first five epochs for seeds0/1/2 stay identical.

Confirmation requires both datasets: positive mean and median Delta_CE vs Z, ≥3/5 CE wins, mean Delta_MRR≥0, positive mean CE advantage over NULL and SHUFFLE. ≥4/5 is separately reported as stronger consistency. If the full gate fails but the selected method improves minimum dataset CE-win count over paired RAW, has positive mean CE and nonnegative MRR on both datasets, and survives both controls, report CHRI_STABILITY_IMPROVED. Otherwise CHRI_WEAK_SIGNAL_ONLY with WEAK_SIGNAL_PERSISTS or STABILIZATION_NOT_RELATION_SPECIFIC/NULL explanation as applicable.

## Correction and optional descriptive analysis

After Phase A, report RAW and all three fixed variants' final correction behavior. After Phase B, compare RAW and the selected variant, including gate mean/std, label strata and correlation with absolute within-model baseline margin. Correlation with labels is a heldout diagnostic only; labels never fit nuisance or donor matching. Numerical nuisance variance measures do not by themselves establish a causal redundancy mechanism.

After every Phase B result is frozen, descriptive confidence subgroups may use frozen NCNC positive-query absolute logits, binned by quartiles fitted on unlabeled training-candidate logits. Report paired CE/MRR for these original-query subsets. These groups never enter encoder features or model selection and are not used for tuning.

## Hard stop boundary

**Test is permanently sealed for this task.** No Cora/PubMed test, Citeseer, I1+I2, CRIB conditional-null penalty, Innovation1 tuning, or Innovation3. Even CHRI_STABILITY_CONFIRMED is not Innovation2 FINAL_FROZEN. The inherited input loader is wrapped to reject all test and third-dataset access.

Required artifacts are explicit NOT_RUN with a reason when blocked by stage gates. Execution errors stop this task's supervisor/children and preserve the log. After successful startup verification the interactive session ends; no long-term monitoring is required. Future V18.2 requires a separate user task.
