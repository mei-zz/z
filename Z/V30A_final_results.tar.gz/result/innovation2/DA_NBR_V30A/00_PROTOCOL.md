# V30A preregistered protocol

{
  "id": "DA_NBR_V30A_EXACT_FINAL5_V1",
  "backbone": "Unmodified official NCNC, jointly trained from scratch",
  "R": "Frozen 75-parameter definition, same constructor/ECDF/masking/pooling",
  "settings": {
    "cora": {
      "xdp": 0.7,
      "tdp": 0.3,
      "pt": 0.75,
      "preedp": 0.4,
      "predp": 0.05,
      "gnndp": 0.05,
      "scale": 4.3,
      "offset": 2.8,
      "alpha": 1.0,
      "gnnlr": 0.0043,
      "prelr": 0.0024,
      "batch": 1152,
      "twolayerlin": false
    },
    "citeseer": {
      "xdp": 0.4,
      "tdp": 0.0,
      "pt": 0.75,
      "preedp": 0.0,
      "predp": 0.55,
      "gnndp": 0.75,
      "scale": 6.5,
      "offset": 4.4,
      "alpha": 0.4,
      "gnnlr": 0.0085,
      "prelr": 0.0078,
      "batch": 384,
      "twolayerlin": true
    },
    "pubmed": {
      "xdp": 0.3,
      "tdp": 0.0,
      "pt": 0.5,
      "preedp": 0.0,
      "predp": 0.05,
      "gnndp": 0.1,
      "scale": 5.3,
      "offset": 0.5,
      "alpha": 0.3,
      "gnnlr": 0.0097,
      "prelr": 0.002,
      "batch": 2048,
      "twolayerlin": false
    }
  },
  "epochs": 5,
  "checkpoint": "final epoch only; validation once",
  "seeds_A": [
    0,
    1,
    2
  ],
  "seeds_B": [
    3,
    4,
    5,
    6,
    7
  ],
  "transfer_seeds": [
    0,
    1,
    2
  ],
  "inner_seeds": [
    8,
    9,
    10
  ],
  "inner_split_seed": 310016,
  "test_opened": false,
  "paths": "All candidate-local simple paths of exactly length3/4; target edge excluded even if present; no cap or sample; bidirectional meet-in-the-middle",
  "transition_features": [
    "log1p(source_endpoint_degree)",
    "log1p(destination_endpoint_degree)",
    "log1p(previous_degree)",
    "log1p(current_degree)",
    "log1p(next_degree)",
    "next_node adjacent to destination in masked train graph",
    "remaining_hops/4",
    "log1p(R_token_count)",
    "current_hops/4",
    "normalized source-destination degree gap"
  ],
  "transition_MLP": "10\u21928 ReLU\u21921 sigmoid,97 parameters; reused for every transition, both path orientations",
  "path_weight": "For each orientation product of L-1 learned transition weights; average both directions; summarize exact count/mean/max",
  "depth": "5\u21928 ReLU\u21922,66 params; masked_softmax; unavailable depth masked; both unavailable representation zero",
  "depth_context": [
    "log1p(T)",
    "log1p(P3)",
    "log1p(P4)",
    "log1p(min masked endpoint degree)",
    "log1p(max masked endpoint degree)"
  ],
  "gate": "3\u21924 ReLU\u21921 sigmoid,21 params; [log1p(T),log1p(P3),log1p(P4)]",
  "head": "14\u21921,15 params, zero weights/bias; new residual199 params",
  "head_input": "5 context +3 depth-fused(count,mean,max) +4 per-depth(mean,max) +2 raw depth logits; all zero if neither depth available",
  "capacity": "B0 baseline; B1 +75R reference; B2\u2013B8 +75R+199 count/routing/capacity module; B9 +75GRAPH+199DA-NBR; full shapes and slot initialization identical",
  "static_capacity": "B2/B3/B5 retain learned transition-shaped 97param count-only capacity mapper (no per-path weighting); its two depth responses enter mean/max slots. Raw depth logits enter head even when fusion fixed, maintaining active capacity in B3/B4. These are stronger learned count controls, not literal untrained count scalars. B2 masks P4, intentional reduced information/effective rank reported. B8 applies all199 params to duplicated GRAPH-only transforms, all trainable; no path/T access in added branch. Fixed-depth B3/B4 masks absent depths and averages available depths. B5 learned depth with count-only static mapping. B6/B7/B9 dynamic path products and learned depth. Gate exists in all matched path arms, so no isolated gate effect claimed.",
  "duplicate_GRAPH": "B8 new capacity module takes two identical copies of the V28 GRAPH vector; polynomial transforms supply ten capacity features; frozen R remains separate",
  "shuffle": "B7 entire candidate path-set+T+endpoint context moves to deterministic donor within exact scheduled occurrence-multiplicity strata; original R branch unchanged; no labels; inherited donor_G from verified common cache; implicit occurrence-label correlation caveat",
  "sampler": "Unmodified official sampler, paired schedules/permutations/dropout RNG; no validation/test label filter",
  "mask": "Host official minibatch-positive maskinput=True; auxiliary features mask only individual target; explicit same scope as frozen R",
  "promotion": "B6-B1 positive mean MRR and at least2/3 paired wins on either dataset",
  "dynamic_control_selection": "For each dataset choose B4 or B5 with higher StageA mean MRR, tie B4; selection is explicitly validation-based, independent seeds assess it",
  "conditional_replication": "B6 exceeds B1/B3/B7/B8/chosen_dynamic in positive mean MRR and strict-majority seed wins on at least one dataset; run one fixed inner TRAIN split for qualifying dataset(s)",
  "no_tuning": true,
  "GPU_workers": 6,
  "route_token_chunk": 65536,
  "determinism": "torch deterministic algorithms; TF32 off; CUBLAS workspace fixed; fixed reduction order; repeated process score tolerance5e-6",
  "symmetry_tolerance": 5e-06,
  "max_new_cache_bytes": 2147483648,
  "minimum_disk_free": 2147483648
}

The host and R weights jointly train. Definition/settings are frozen. The full requested B0–B9 are executed. The count controls contain an active learned count-only capacity mapper, not unused dummy weights; they are stronger controls. B4 depth logits remain direct capacity covariates while fusion is fixed. B8 all199 parameters operate on duplicate GRAPH information. Gate causality remains unresolved without a separate ungated contrast. No test member is decompressed.
